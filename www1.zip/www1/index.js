const button = document.getElementById("themeSwitcher");
const divs = document.querySelectorAll("div");
let theme = "light";

function toggleTheme() {
    const isLight = theme === "light";

    divs.forEach((element) => {
        element.style.backgroundColor = isLight ? "#333" : "#d3d3d3";
        element.style.color = isLight ? "#d3d3d3" : "#333";
    });

    theme = isLight ? "dark" : "light";
}

button.addEventListener("click", toggleTheme);